-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 10, 2022 at 10:40 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `leave_application`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `emp_no` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `no_tel` varchar(100) NOT NULL,
  `pass` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `emp_no`, `email`, `no_tel`, `pass`) VALUES
(1, 'admin 12', '0002', 'test@gmail.com', 'efefef', '123'),
(2, 'TEST1', 'TEST1', 'test@gmail.com', '4314335', 'test1');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `id` int(100) NOT NULL,
  `emp_no` varchar(225) NOT NULL,
  `name` varchar(225) NOT NULL,
  `dept` varchar(225) NOT NULL,
  `no_tel` varchar(100) NOT NULL,
  `leaves_bal` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `emp_no`, `name`, `dept`, `no_tel`, `leaves_bal`) VALUES
(1, '2', 'frrg', 'STORE', '1111111', 11),
(5, '8744', 'd', 'ENGINEERING', '3232332', 0),
(6, 'w', 'w', 'PURCHASING', '2', 3),
(8, 'w', 'w', 'PURCHASING', '2', 3),
(10, 'w', 'w', 'PURCHASING', '2', 3),
(11, 'w', 'w', 'PURCHASING', '2', 3);

-- --------------------------------------------------------

--
-- Table structure for table `hr`
--

CREATE TABLE `hr` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `emp_no` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `no_tel` varchar(100) NOT NULL,
  `pass` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

--
-- Dumping data for table `hr`
--

INSERT INTO `hr` (`id`, `name`, `emp_no`, `email`, `no_tel`, `pass`) VALUES
(1, 'Nur Hidayah Binti Ansari', 'S0098', 'hidayah@gmail.com', '012233223', '123'),
(2, 'TEST2', 'test2', 'test@gmail.com', '2322332', '123'),
(3, 'TEST1', 'test1', 'test@gmail.com', '231231', 'test');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `name` varchar(100) NOT NULL,
  `id` int(100) NOT NULL,
  `emp_no` varchar(20) NOT NULL,
  `dept` varchar(30) NOT NULL,
  `day` int(10) NOT NULL,
  `start` date NOT NULL,
  `end` date NOT NULL,
  `half_day` varchar(100) NOT NULL,
  `reason` varchar(100) NOT NULL,
  `type_leave` varchar(100) NOT NULL,
  `others` varchar(250) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  `process` varchar(100) NOT NULL,
  `process_hod` varchar(100) NOT NULL,
  `balanced_AL` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`name`, `id`, `emp_no`, `dept`, `day`, `start`, `end`, `half_day`, `reason`, `type_leave`, `others`, `date`, `process`, `process_hod`, `balanced_AL`) VALUES
('email', 1, 'S0098', 'ACCOUNT', 3, '2022-09-13', '2022-09-15', 'Evening', '3', 'Traning', '', '2022-09-13', 'Review', '', '3'),
('nur hidayah', 2, 'S0098', 'ACCOUNT', 3, '2022-09-13', '2022-09-15', 'Evening', '2', 'Medical', '', '2022-09-13', 'Review', '', '3'),
('nur hidayah', 3, 'S0098', 'ACCOUNT', 3, '2022-09-13', '2022-09-15', 'Evening', '2', 'Medical', '', '2022-09-13', 'Review', '', '3'),
('test 2', 4, 'S0001', 'QA', 2, '2022-09-13', '2022-09-15', 'Evening', '2', 'Medical', '', '2022-09-13', 'Review', '', ''),
('sqs', 5, 'S', 'PRODUCTION', 2, '2022-09-17', '2022-09-24', 'Evening', 'S', 'Others', 'OTHER', '2022-09-14', 'Review', 'APPROVED', ''),
('sqs', 6, 'S', 'PRODUCTION', 2, '2022-09-17', '2022-09-24', 'Evening', 'S', 'Others', 'OTHER', '2022-09-14', 'Review', 'APPROVED', ''),
('TEST', 7, '0001', 'ACCOUNT', 4, '2022-09-14', '2022-09-16', 'Evening', 'ww', 'Annual', '', '2022-09-14', 'Review', 'CANCELLED', ''),
('no_tel', 8, '0001', 'QA', 2, '2022-09-14', '2022-09-21', '', 's', 'Medical', '', '2022-09-14', 'Review', 'CANCELLED', ''),
('TEST', 9, '1111', 'ACCOUNT', 2, '2022-09-15', '2022-09-17', 'Evening', '2', 'Annual', '', '2022-09-15', 'Review', 'APPROVED', ''),
('TEST', 10, '1111', 'ACCOUNT', 2, '2022-09-15', '2022-09-17', 'Evening', '2', 'Annual', '', '2022-09-15', 'Review', 'APPROVED', ''),
('no_tel', 11, '0001', 'ENGINEERING', 2, '2022-09-15', '2022-09-16', '', '2', 'Annual', '', '2022-09-15', 'Review', 'CANCELLED', ''),
('TEST', 12, '0001', 'HR', 2, '2022-09-15', '2022-09-23', 'Evening', 'we', 'Marriage', '', '2022-09-15', 'Review', 'CANCELLED', ''),
('TEST', 13, '0001', 'MARKETING', 2, '2022-09-15', '2022-09-23', 'Evening', 'we', 'Marriage', '', '2022-09-15', 'Review', 'CANCELLED', ''),
('TEST', 14, '0001', 'PURCHASING', 2, '2022-09-15', '2022-09-23', 'Evening', 'we', 'Marriage', '', '2022-09-15', 'Review', 'CANCELLED', ''),
('TEST', 15, '0001', 'QA', 2, '2022-09-15', '2022-09-23', 'Evening', 'we', 'Marriage', '', '2022-09-15', 'Review', 'CANCELLED', ''),
('TEST', 16, '0001', 'QC', 2, '2022-09-15', '2022-09-23', 'Evening', 'we', 'Marriage', '', '2022-09-15', 'Review', 'CANCELLED', ''),
('TEST', 17, '0001', 'STORE', 2, '2022-09-15', '2022-09-23', 'Evening', 'we', 'Marriage', '', '2022-09-15', 'Review', 'CANCELLED', ''),
('TEST', 18, '0001', 'STORE', 2, '2022-09-15', '2022-09-23', 'Evening', 'we', 'Marriage', '', '2022-09-15', 'Review', 'CANCELLED', ''),
('TEST', 19, '0001', 'STORE', 2, '2022-09-15', '2022-09-23', 'Evening', 'we', 'Marriage', '', '2022-09-15', 'Review', 'CANCELLED', ''),
('no_tel', 21, '0001', 'STORE', 2, '2022-09-23', '2022-10-20', 'Evening', 'e', 'Medical', '', '2022-09-15', 'Review', 'CANCELLED', ''),
('no_tel', 22, '0001', 'SYSTEM', 2, '2022-09-23', '2022-10-20', 'Evening', 'e', 'Medical', '', '2022-09-15', 'Review', 'CANCELLED', ''),
('TEST', 23, '0001', 'QC', 2, '2022-09-15', '2022-09-23', '', 'ss', 'Annual', '', '2022-09-15', 'Review', 'Review', ''),
('TEST', 24, '0001', 'QC', 2, '2022-09-15', '2022-09-23', 'Evening', 'ss', 'Annual', '', '2022-09-15', 'Review', 'Review', ''),
('TEST', 25, '0001', 'QC', 2, '2022-09-15', '2022-09-23', 'Evening', 'ss', 'Annual', '', '2022-09-15', 'Review', 'Review', ''),
('TEST', 26, '0001', 'QC', 2, '2022-09-15', '2022-09-23', 'Evening', 'ss', 'Annual', '', '2022-09-15', 'Review', 'Review', ''),
('TEST', 27, '0001', 'QC', 2, '2022-09-15', '2022-09-23', '', 'ss', 'Annual', '', '2022-09-15', 'Review', 'Review', ''),
('', 31, 'S0098', '', 0, '0000-00-00', '0000-00-00', '', '', '', '', '0000-00-00', 'Review', 'Review', ''),
('', 32, 'S0098', '', 0, '0000-00-00', '0000-00-00', '', '', '', '', '0000-00-00', 'Review', 'Review', ''),
('', 33, 'S0098', '', 0, '0000-00-00', '0000-00-00', '', '', '', '', '0000-00-00', 'Review', 'Review', ''),
('', 34, 'S0098', '', 0, '0000-00-00', '0000-00-00', '', '', '', '', '0000-00-00', 'Review', 'Review', ''),
('', 35, '2', '', 0, '0000-00-00', '0000-00-00', '', '', '', '', '0000-00-00', 'Review', 'Review', ''),
('', 36, '2', '', 0, '0000-00-00', '0000-00-00', '', '', '', '', '0000-00-00', 'Review', 'Review', ''),
('', 37, '2', '', 0, '0000-00-00', '0000-00-00', '', '', '', '', '0000-00-00', 'Review', 'Review', ''),
('', 38, '2', '', 0, '0000-00-00', '0000-00-00', '', '', '', '', '0000-00-00', 'Review', 'Review', ''),
('', 39, '2', '', 0, '0000-00-00', '0000-00-00', '', '', '', '', '0000-00-00', 'Review', 'Review', ''),
('frrg', 40, '', 'ACCOUNT', 2, '2022-09-23', '2022-09-24', 'Evening', '2', 'Annual', '', '2022-09-23', 'Review', 'Review', ''),
('frrg', 41, '2', 'ACCOUNT', 4, '2022-09-30', '2022-10-25', 'Evening', 'dddd', 'Medical', '', '2022-09-23', 'Review', 'Review', ''),
('', 42, '', 'STORE', 2, '2022-09-13', '2022-09-17', 'Evening', '2', 'Paternity', '', '2022-09-23', 'Review', 'Review', ''),
('', 43, '', 'STORE', 2, '2022-09-13', '2022-09-17', 'Evening', '2', 'Paternity', '', '2022-09-23', 'Review', 'Review', ''),
('frrg', 44, '2', 'ACCOUNT', 2, '2022-09-23', '2022-09-29', 'Fullday', 'dddd', 'Medical', '', '0000-00-00', 'Review', 'Review', ''),
('frrg', 45, '2', 'NULL', 3, '2022-09-26', '2022-10-24', 'Fullday', '3w', 'Maternity', '', '0000-00-00', 'Review', 'Review', ''),
('frrg', 46, '2', 'ENGINEERING', 2, '0000-00-00', '0000-00-00', 'Fullday', 'www', '', '', '0000-00-00', 'Review', 'Review', ''),
('frrg', 47, '2', 'ACCOUNT', 2, '2022-09-21', '2022-09-22', 'Fullday', '2', '', '', '0000-00-00', 'Review', 'Review', ''),
('frrg', 48, '2', 'ACCOUNT', 3, '2022-09-23', '2022-09-30', 'Fullday', '3', 'Marriage', '', '0000-00-00', 'Review', 'Review', ''),
('frrg', 49, '2', 'ACCOUNT', 3, '2022-09-24', '2022-10-26', 'Fullday', '3', 'Marriage', '', '0000-00-00', 'Review', 'Review', ''),
('frrg', 50, '2', 'ACCOUNT', 3, '2022-09-23', '2022-09-30', 'Evening', 'w', 'Annual', '', '0000-00-00', 'Review', 'Review', ''),
('frrg', 51, '2', 'ACCOUNT', 3, '2022-09-23', '2022-09-30', 'Evening', '3', 'Medical', '', '0000-00-00', 'Review', 'Review', ''),
('frrg', 52, '2', 'ACCOUNT', 2, '2022-09-23', '2022-09-29', 'Evening', '2', 'Maternity', '', '2022-09-23', 'Review', 'Review', '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `role` enum('acc','engineer','hr','marketing','prod','purchasing','qa','qc','stor','system') NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `no_tel` varchar(100) NOT NULL,
  `dept` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `role`, `username`, `password`, `name`, `email`, `no_tel`, `dept`) VALUES
(1, 'acc', 'S0001', '12345', 'HOD ACCOUNT', 'kennwufact@gmail.com', '0123333333', 'ACCOUNT'),
(2, 'engineer', 'S0002', '12345', 'HOD ENGINEERING', 'nurhidayah9501@gmail.com', '0192883745', 'ENGINEERING'),
(3, 'hr', 'S0003', '12345', 'HOD HR', 'linaansari9501@gmail.com', '0182737202', 'HR'),
(4, 'marketing', 'S0004', '12345', 'HOD MARKETING', 'kennwufact@gmail.com', '0198727389', 'MARKETING'),
(5, 'prod', 'S0005', '12345', 'HOD PROD', 'peachbeehq@gmail.com', '0123383334', 'PRODUCTION'),
(6, 'purchasing', 'S0006', '12345', 'HOD PURCHASING', 'nrdyhq9501@gmail.com', '0192888392', 'PURCHASING'),
(7, 'qa', 'S0007', '12345', 'HOD QA', 'kennwufact@gmail.com', '0193773845', 'QA'),
(8, 'qc', 'S0008', '12345', 'HOD QC', 'blumilkco@gmail.com', '0173493993', 'QC'),
(9, 'stor', 'S0009', '12345', 'HOD STORE', 'pinkla9501@gmail.com', '015732892', 'STORE'),
(10, 'system', 'S0010', '12345', 'HOD SYSTEM', 'nurhidayah951@yahoo.com', '0148299388', 'SYSTEM');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hr`
--
ALTER TABLE `hr`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `hr`
--
ALTER TABLE `hr`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
